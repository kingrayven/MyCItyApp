package com.example.mycity.data

import com.example.mycity.R

object Datasource {

    private val restaurantsCategory = Category(
        name = R.string.restaurants_category,
        icon = R.drawable.restaurant_icon,
        list = listOf(
            Place(
                name = R.string.cafe_title,
                description = R.string.cafe_description,
                address = R.string.cafe_address,
                photo = R.drawable.cafe
            ),
            Place(
                name = R.string.lilo_title,
                description = R.string.lilo_description,
                address = R.string.lilo_address,
                photo = R.drawable.lilang
            ),
            Place(
                name = R.string.irene_title,
                description = R.string.irene_description,
                address = R.string.irene_address,
                photo = R.drawable.irene
            ),
            Place(
                name = R.string.cocina_title,
                description = R.string.cocina_description,
                address = R.string.cocina_address,
                photo = R.drawable.cocina
            )
        )
    )

    private val barsCategory = Category(
        name = R.string.bars_category,
        icon = R.drawable.bar_icon,
        list = listOf(
            Place(
                name = R.string.bistro_title,
                description = R.string.bistro_description,
                address = R.string.bistro_address,
                photo = R.drawable.bistro
            ),
            Place(
                name = R.string.legacy_title,
                description = R.string.legacy_description,
                address = R.string.legacy_address,
                photo = R.drawable.legacy
            )
        )
    )
    private val parksCategory=Category(
        name=R.string.parks_category,
        icon = R.drawable.nature_icon,
        list=listOf(
            Place(
                name = R.string.bell_title,
                description = R.string.bell_description,
                address = R.string.bell_address,
                photo = R.drawable.bantay
            ),
            Place(
                name = R.string.hidden_title,
                description = R.string.hidden_description,
                address = R.string.hidden_address,
                photo = R.drawable.garden
            )
        )
    )
    private val shopsCategory=Category(
        name=R.string.shops_category,
        icon=R.drawable.shops_icon,
        list = listOf(
            Place(
                name = R.string.marsha_title,
                description = R.string.marsha_description,
                address = R.string.marsha_address,
                photo = R.drawable.marsha
            ),
            Place(
                name = R.string.jar_title,
                description = R.string.jar_description,
                address = R.string.jar_address,
                photo = R.drawable.jar
            ),
            Place(
                name = R.string.empo_title,
                description = R.string.empo_description,
                address = R.string.empo_address,
                photo = R.drawable.eporium
            )
        )
    )

    private val attractionsCategory= Category(
        name = R.string.inns_category,
        icon = R.drawable.attractions_icon,
        list = listOf(
            Place(
                name = R.string.luna_title,
                description = R.string.luna_description,
                address = R.string.luna_address,
                photo = R.drawable.luna
            ),
            Place(
                name = R.string.grandpa_title,
                description = R.string.grandpa_description,
                address = R.string.grandpa_address,
                photo = R.drawable.grandpa
            ),
            Place(
                name = R.string.plaza_title,
                description = R.string.plaza_description,
                address = R.string.plaza_address,
                photo = R.drawable.bantay
            ),
            Place(
                name = R.string.casa_title,
                description = R.string.casa_description,
                address = R.string.casa_address,
                photo = R.drawable.rica
            )
        )

    )
    val listOfCategories = listOf(restaurantsCategory, barsCategory, parksCategory, shopsCategory, attractionsCategory)

}