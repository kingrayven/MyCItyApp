package com.example.mycity.utils

enum class WindowStateContentType{
    ListOnly, ListDetail
}