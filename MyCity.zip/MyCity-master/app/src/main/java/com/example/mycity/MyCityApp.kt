package com.example.mycity

import androidx.annotation.StringRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.mycity.data.Category
import com.example.mycity.ui.*
import com.example.mycity.ui.MyCityScreen
import com.example.mycity.utils.WindowStateContentType
import com.example.mycity.ui.theme.MyCityTheme
import com.example.mycity.ui.MyCityUiState
import com.example.mycity.ui.MyCityViewModel

enum class MyCityScreen {
    Start, CategoryList, PlacesList, Place
}

@Composable
fun MyCityApp(
    windowSize: WindowWidthSizeClass,
    navController: NavHostController = rememberNavController(),
    viewModel: MyCityViewModel = viewModel()
) {
    val contentType = when (windowSize) {
        WindowWidthSizeClass.Expanded -> WindowStateContentType.ListDetail
        else -> WindowStateContentType.ListOnly
    }
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentScreen = MyCityScreen.valueOf(
        backStackEntry?.destination?.route ?: MyCityScreen.Start.name
    )
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            com.example.mycity.ui.MyCityAppBar(
                title = determineTopBarTitle(currentScreen.name, uiState),
                canNavigateBack = navController.previousBackStackEntry != null,
                navigateUp = { navController.navigateUp() },
            )
        },
        bottomBar = {
            if (shouldButtonsAppear(currentScreen, contentType)) {
                when (currentScreen) {
                    MyCityScreen.Start -> {
                        com.example.mycity.ui.NavButtonsAppBar(
                            nextFunction = { navController.navigate(MyCityScreen.CategoryList.name) },
                            hasPreviousButton = false
                        )
                    }
                    MyCityScreen.PlacesList -> {
                        com.example.mycity.ui.NavButtonsAppBar(
                            nextFunction = {
                                viewModel.getNextCategory()
                                    ?.let { viewModel.updateCurrentCategory(it) }
                            },
                            hasPreviousButton = true,
                            previousFunction = {
                                viewModel.getPreviousCategory()
                                    ?.let { viewModel.updateCurrentCategory(it) }
                            },
                            nextImageId = if (uiState.currentCategory != null) determineIcon(
                                viewModel.getNextCategory()
                            ) else -1,
                            previousImageId = determineIcon(viewModel.getPreviousCategory())
                        )
                    }
                    MyCityScreen.Place -> {
                        com.example.mycity.ui.NavButtonsAppBar(
                            nextFunction = {
                                viewModel.getNextPlace()?.let { viewModel.updateCurrentPlace(it) }
                            },
                            hasPreviousButton = true,
                            previousFunction = {
                                viewModel.getPreviousPlace()
                                    ?.let { viewModel.updateCurrentPlace(it) }
                            },
                            nextImageId = determineIcon(uiState.currentCategory),
                            previousImageId = determineIcon(uiState.currentCategory)
                        )
                    }

                    MyCityScreen.CategoryList -> TODO()
                }
            }
        }
    ) { innerPadding ->
        NavHost(navController = navController, startDestination = MyCityScreen.Start.name) {
            composable(route = MyCityScreen.Start.name) {
                when (contentType) {
                    WindowStateContentType.ListDetail -> {
                        ExpandedStartScreen(
                            viewModel = viewModel,
                            uiState = uiState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        )
                    }
                    else -> StartScreen(modifier = Modifier.fillMaxSize())
                }
            }
            composable(route = MyCityScreen.CategoryList.name) {
                PickCategoryScreen(
                    viewModel = viewModel,
                    navigateFunction = { navController.navigate(MyCityScreen.PlacesList.name) },
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
            composable(route = MyCityScreen.PlacesList.name) {
                PickPlaceScreen(
                    navigateFunction = { navController.navigate(MyCityScreen.Place.name) },
                    viewModel = viewModel,
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
            composable(route = MyCityScreen.Place.name) {
                PlaceScreen(
                    uiState = uiState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
        }
    }
}

private fun shouldButtonsAppear(
    currentScreen: MyCityScreen,
    contentType: WindowStateContentType
) =
    currentScreen.name != MyCityScreen.CategoryList.name && contentType != WindowStateContentType.ListDetail

private fun determineTopBarTitle(
    currentScreen: String, uiState: MyCityUiState
) = when (currentScreen) {
    MyCityScreen.CategoryList.name -> R.string.places
    MyCityScreen.PlacesList.name -> uiState.currentCategory!!.name
    MyCityScreen.Place.name -> uiState.currentCategory!!.name
    else -> R.string.app_name
}

private fun determineIcon(category: Category?): Int {
    return when (category?.name) {
        R.string.restaurants_category -> R.drawable.restaurant_icon
        R.string.bars_category -> R.drawable.bar_icon
        R.string.shops_category -> R.drawable.shops_icon
        R.string.parks_category -> R.drawable.nature_icon
        R.string.inns_category -> R.drawable.attractions_icon
        else -> -1
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCityAppBar(
    modifier: Modifier = Modifier,
    @StringRes title: Int = R.string.app_name,
    canNavigateBack: Boolean,
    navigateUp: () -> Unit
) {
    TopAppBar(
        colors = TopAppBarDefaults.mediumTopAppBarColors(containerColor = MaterialTheme.colorScheme.primary),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Text(
                    text = stringResource(id = title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f) // Use weight for responsiveness
                )

                Spacer(modifier = Modifier.width(8.dp))

                if (title == R.string.app_name) {
                    Image(
                        painter = painterResource(id = R.drawable.one),
                        contentDescription = null,
                        modifier = Modifier
                            .size(50.dp) // Adjust size if necessary
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        },
        modifier = modifier,
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(onClick = navigateUp) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = stringResource(id = R.string.back_button)
                    )
                }
            }
        }
    )
}

@Composable
fun NavButtonsAppBar(
    nextFunction: () -> Unit,
    modifier: Modifier = Modifier,
    nextImageId: Int = -1,
    previousImageId: Int = -1,
    hasPreviousButton: Boolean,
    previousFunction: () -> Unit = {}
) {
    BottomAppBar {
        Row(horizontalArrangement = Arrangement.End, modifier = modifier.fillMaxWidth()) {
            if (hasPreviousButton) {
                com.example.mycity.ui.PreviousButton(
                    onClick = previousFunction,
                    imageId = previousImageId
                )
                Spacer(modifier = Modifier.weight(1f))
            }
            com.example.mycity.ui.NextButton(onClick = nextFunction, imageId = nextImageId)
        }
    }
}

@Composable
fun NextButton(onClick: () -> Unit, imageId: Int, modifier: Modifier = Modifier) {
    Button(
        onClick = { onClick() },
        modifier = modifier.padding(dimensionResource(id = R.dimen.padding_medium))
    ) {
        Text(
            text = stringResource(id = R.string.next_button),
            style = MaterialTheme.typography.labelMedium
        )
        if (imageId != -1) Icon(
            imageVector = ImageVector.vectorResource(id = imageId),
            contentDescription = null,
            modifier = Modifier.padding(start = dimensionResource(id = R.dimen.padding_small))
        )
        Icon(
            imageVector = Icons.Default.KeyboardArrowRight,
            contentDescription = null,
        )
    }
}

@Composable
fun PreviousButton(onClick: () -> Unit, imageId: Int, modifier: Modifier = Modifier) {
    Button(
        onClick = { onClick() },
        modifier = modifier.padding(dimensionResource(id = R.dimen.padding_medium))
    ) {
        if (imageId != -1) Icon(
            imageVector = ImageVector.vectorResource(id = imageId),
            contentDescription = null,
            modifier = Modifier.padding(end = dimensionResource(id = R.dimen.padding_small))
        )
        Icon(
            imageVector = Icons.Default.KeyboardArrowLeft,
            contentDescription = null,
        )
        Text(
            text = stringResource(id = R.string.previous_button),
            style = MaterialTheme.typography.labelMedium
        )
    }
}

// Preview Functions
@Preview(showBackground = true, device = Devices.PIXEL_4)
@Composable
fun MyCityAppPreview() {
    MyCityTheme {
        com.example.mycity.ui.MyCityApp(windowSize = WindowWidthSizeClass.Compact)
    }
}

@Preview(showBackground = true, device = Devices.PIXEL_4)
@Composable
fun MyCityAppBarPreview() {
    MyCityTheme {
        com.example.mycity.ui.MyCityAppBar(
            title = R.string.app_name,
            canNavigateBack = true,
            navigateUp = {}
        )
    }
}
